package test;

import java.awt.image.BufferedImage;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import com.interf.test.TestRemote;
import com.github.sarxos.webcam.Webcam;

import javax.imageio.ImageIO;



public class RemoteImpl extends UnicastRemoteObject implements TestRemote {

    private static final long serialVersionUID = 1L;

    protected RemoteImpl() throws RemoteException {

    }

    public boolean isLoginValid(String username) throws RemoteException {
        if (username.equals("test")) {
            return true;
        }
        return false;
    }

    public int add(int a, int b) throws RemoteException {
        return a + b;
    }

    public byte[] getBytes() throws RemoteException {
        Webcam webcam = Webcam.getDefault();
        webcam.open();
        BufferedImage image = webcam.getImage();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            ImageIO.write(image, "jpg", baos);
            baos.flush();
            byte[] imageInByte = baos.toByteArray();
            baos.close();
            return imageInByte;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new byte[0];
    }

    public Webcam getWebcam() throws RemoteException {
        return Webcam.getDefault();
    }





}
