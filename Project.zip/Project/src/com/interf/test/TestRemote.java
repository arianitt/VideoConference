package com.interf.test;

import com.github.sarxos.webcam.Webcam;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface TestRemote extends Remote {


    public boolean isLoginValid(String username) throws RemoteException;

    public int add(int a,int b) throws RemoteException;

    public byte[] getBytes() throws RemoteException;

    public Webcam getWebcam() throws RemoteException;

}
