package com.interf.test;


public class Constant {

    public static final String RMI_ID="TestRMI";
 
    public static final int RMI_PORT=0;
   


}
