package client;

import com.github.sarxos.webcam.Webcam;
import com.interf.test.Constant;
import com.interf.test.TestRemote;

import javax.imageio.ImageIO;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.ByteArrayInputStream;

import java.io.IOException;
import java.io.InputStream;
import java.rmi.NotBoundException;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;



public class TestClient {

	public static boolean cam1 = true;
	public static boolean cam2 = true;
	public static boolean cam3 = true;
	public static boolean cam4 = true;
	
	
    public static void main(String[] args) throws IOException, NotBoundException {
        System.out.println("Client is started");
            
            View view1 = new View();
            View view2 = new View();
            View view3 = new View();
            View view4 = new View();
            AddPanel paneli = new AddPanel(view1, view2, view3, view4);
            AktivizoFramen a = new AktivizoFramen(paneli);
            new KontrolloFramein(paneli).run();
		
        
        
    }
}
class View
{	private static Image image = null;
	private static Image image2 = null;
	private static Image image3 = null;
	private static Image image4 = null;
	View() throws NotBoundException, IOException
	{
		
	}
	
	public static void updatImage1()throws NotBoundException, IOException
	{
		Registry registry=LocateRegistry.getRegistry("185.218.33.28", 8080);
	    TestRemote remote= (TestRemote) registry.lookup(Constant.RMI_ID);
		InputStream in=new ByteArrayInputStream(remote.getBytes());
		image = ImageIO.read(in);
	
	}
	public static void updatImage2()throws NotBoundException, IOException
	{
		Registry registry=LocateRegistry.getRegistry("183.168.43.2", 1099);
	    TestRemote remote= (TestRemote) registry.lookup(Constant.RMI_ID);
		InputStream in=new ByteArrayInputStream(remote.getBytes());
		image2 = ImageIO.read(in);

	}
	public static void updatImage3()throws NotBoundException, IOException
	{
		Registry registry=LocateRegistry.getRegistry("192.168.43.240", 9090);
	    TestRemote remote= (TestRemote) registry.lookup(Constant.RMI_ID);
		InputStream in=new ByteArrayInputStream(remote.getBytes());
		image3 = ImageIO.read(in);

	}
	public static void updatImage4()throws NotBoundException, IOException
	{
		Registry registry=LocateRegistry.getRegistry("localhost", 80);
	    TestRemote remote= (TestRemote) registry.lookup(Constant.RMI_ID);
		InputStream in=new ByteArrayInputStream(remote.getBytes());
		image4 = ImageIO.read(in);

	}
        
	public static Image getView1() 
	{
		try {
			updatImage1();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return image;
	}
	public static Image getView2() 
	{
		try {
			updatImage2();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return image2;
	}
	public static Image getView3() 
	{
		try {
			updatImage3();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return image3;
	}
	public static Image getView4() 
	{
		try {
			updatImage4();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return image4;
	}
}
class  AktivizoFramen extends JFrame
{
	public AktivizoFramen(AddPanel p)
	{
		JFrame frame = new JFrame();
		frame.setSize(1350,550);
		

		JButton b1 = new JButton("Stop/Start Cam1");
		JButton b2 = new JButton("Stop/Start Cam2");
		JButton b3 = new JButton("Stop/Start Cam3");
		JButton b4 = new JButton("Stop/Start Cam4");
		JPanel bPanel = new JPanel();
		b1.addActionListener(new ActionListener(){
		
			public void actionPerformed(ActionEvent e)
			{
				if(TestClient.cam1==false)
				{
					TestClient.cam1 = true;
				}
				else
				{
					TestClient.cam1 = false;
				}
			}
		}
		
		);
		
		b2.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e)
			{
				if(TestClient.cam2==false)
				{
					TestClient.cam2 = true;
				}
				else
				{
					TestClient.cam2 = false;
				}
			}
		}
		
		);
		b3.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e)
			{
				if(TestClient.cam3==false)
				{
					TestClient.cam3 = true;
				}
				else
				{
					TestClient.cam3 = false;
				}
			}
		}
		
		);
	b4.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e)
			{
				if(TestClient.cam4==false)
				{
					TestClient.cam4 = true;
				}
				else
				{
					TestClient.cam4 = false;
				}
			}
		}
		
		);
		b1.setSize(100,200);
		b2.setSize(100,200);
		b3.setSize(100,200);
		JLabel lbl  = new JLabel("                                        ");
		JLabel lbl2 = new JLabel("                                        ");
		JLabel lbl3 = new JLabel("                                        ");
		bPanel.add(b1);
		bPanel.add(lbl);
		bPanel.add(b2);
		bPanel.add(lbl2);
		bPanel.add(b3);
		bPanel.add(lbl3);
		bPanel.add(b4);
		
		bPanel.setSize(800, 400);
//		JLabel autor = new JLabel(" AUTOR: ENDRIT XHEMAILI \n FISNIK ALIU  \n ALMIRA SYLA  \n  RAMADAN HASANI");
//		bPanel.add(autor);
		frame.setLayout(new GridLayout(2,1));
		frame.add(p);
		frame.add(bPanel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
	}
}


class AddPanel extends JPanel
{
	private int i = 0;
	Image image1  = null;
	Image image2  = null;
	Image image3  = null;
	Image image4  = null;
	private View view1;
	private View view2;
	private View view3;
	private View view4;
	
	public AddPanel(View p, View p2, View p3, View p4)
	{
		view1 = p;
		view2= p2;
		view3 = p3;
		view4 = p4;
		image1 = view1.getView1();
		image2 = view2.getView2();
		image3 = view3.getView3();
		image4 = view4.getView4();
	}
	
	public  void paintComponent(Graphics g)
	   {
		 g.setColor(Color.white);
		 g.fillRect(0, 0, 1400, 1000);
		 if(TestClient.cam1)
		 {
			 image1 = view1.getView1();
			 g.drawImage(image1, 10, 10,320,240, null);
		 }
		 else
		 {
			 g.drawImage(null, 10, 10,320,240, null);
		 }
	     if(TestClient.cam2)
	     {
	    	 image2 = view2.getView2();
	    	 g.drawImage(image2, 350, 10,320,240, null);
	     }
	     else
		 {
			 g.drawImage(null, 350, 10,320,240, null);
		 }
	     if(TestClient.cam3)
	     {
	    	 image3 = view3.getView3();
	    	 g.drawImage(image3, 690, 10,320,240, null);
	     }
	     else
		 {
			 g.drawImage(null, 700, 10,320,240, null);
		 }
	     if(TestClient.cam4)
	     {
	    	 image4 = view4.getView4();
	    	 g.drawImage(image4, 1025, 10,320,240, null);
	     }
	     else
		 {
			 g.drawImage(null, 1000, 10,320,240, null);
		 }
	   }     
	     
}

class KontrolloFramein
{
	private AddPanel paneli = null;
	private View pamja = null;
	public KontrolloFramein(AddPanel pan)
	{	
		paneli = pan;
		
	}
	public void run()
	{
		while (true)
		{

			paneli.repaint();
			
			
			try {
				Thread.sleep(0);
			} catch (Exception e) {
				
			}
		}
	}
}



